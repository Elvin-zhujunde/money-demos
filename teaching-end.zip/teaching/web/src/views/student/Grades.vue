<template>
  <div>
    <h2>成绩查询</h2>
  </div>
</template>

<script setup>
</script> 