# 教学管理系统接口文档

## 基础说明
- 基础URL: `http://localhost:8088`
- 所有请求都需要在header中携带Content-Type: application/json
- 响应格式统一为：